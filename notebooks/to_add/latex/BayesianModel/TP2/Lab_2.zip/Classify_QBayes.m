function [erreur predict confusion]= Classify_QBayes(data_learning, labels_learning, data_test, labels_test)
    
    erreur = 0;
    confusion = zeros(10,10);
    
    for c = 1:10
        S(c,:,:) =cov(data_learning(labels_learning==c,:));
        M(c,:) = mean(data_learning(labels_learning==c,:))';
    end
    
    n = size(data_test,1);
    predict = zeros(1,n);

    for i = 1:n
%         i,
        for j = 1:10
            b(i,j) = posteriori(data_test(i,:)',j,M,S);
        end
        [bs ind] = sort(b(i,:),'descend');

        predict(i) = ind(1);
        
        confusion(labels_test(i),ind(1)) = confusion(labels_test(i),ind(1))+1;

        if ind(1) ~= labels_test(i)
            erreur = erreur +1; 
        end
    end
    
    erreur = erreur/n;
end