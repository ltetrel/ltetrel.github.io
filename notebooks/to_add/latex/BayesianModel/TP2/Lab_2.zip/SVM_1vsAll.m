function [rate predict confusion] = SVM_1vsAll(data_learning, labels_learning, data_valid, labels_test, gkernel,gam)
    
    rate = 0;
    predict = zeros(size(data_valid,1),1);
    r = zeros(size(data_valid,1),10);
    output = zeros(size(data_valid,1),10);
    for c = 1:10
        c,
        lab_learn = zeros(size(labels_learning));
        lab_val = zeros(size(labels_test));
        lab_learn(labels_learning==c) = 1;
        lab_learn(labels_learning~=c) = -1;
        lab_val(labels_test==c) = 1;
        lab_val(labels_test~=c) = -1;
        [r(:,c) output(:,c)] = Classify_svm(data_learning,lab_learn,data_valid,lab_val,gkernel,gam,gam);
    end
    confusion = zeros(10,10);
    for i = 1:size(data_valid,1)
        [val ind] = max(output(i,:));
        predict(i) = ind;
        
        confusion(labels_test(i),ind) = confusion(labels_test(i),ind)+1;
        
        if predict(i) ~= labels_test(i)
            rate = rate + 1/size(data_valid,1);
        end
    end
end