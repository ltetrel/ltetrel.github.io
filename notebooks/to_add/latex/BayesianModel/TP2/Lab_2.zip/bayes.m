function r = bayes(x, S, M)
    d = size(S,1);
    
    r = (1/((2*pi)^(d/2)*det(S)^0.5))*exp(-0.5*((x-M)')*inv(S)*(x-M));
end
