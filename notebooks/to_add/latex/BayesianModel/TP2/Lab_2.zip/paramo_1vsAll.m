function [gamo Co r] = paramo_1vsAll(data_learning, labels_learning, data_valid, labels_valid, Vgam,VC)
    ng = size(Vgam,2);
    nc = size(VC,2);
    
    rate = zeros(ng, nc);
    
    for g = 1:ng
        for c = 1:nc
            [rate(g, c) ~] = SVM_1vsAll(data_learning, labels_learning, data_valid, labels_valid, Vgam(g),VC(c));
        end
    end
    
    [mv mi] = min(rate);
    [v i] = min(mv);
    
    gamo = Vgam(mi(i));
    Co = VC(i);
%     r = rate(mi(i), i);
    r = rate;
end

    
            
    