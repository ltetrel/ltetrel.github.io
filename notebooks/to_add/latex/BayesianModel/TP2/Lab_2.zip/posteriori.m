% � Posteriori

function Pcx = posteriori(x, c, M, S)
%     Pc = 1/10;
%     Pxc = zeros(1,10);
%     for i = 1:10
%         Sc(:,:) = S(i,:,:);
%         Mc = M(i,:)';
% %         Pxc(i) = bayes(x,Sc,Mc);
%        Pxc(i) = -0.5*log(det(Sc))-0.5*((x-Mc)')*inv(Sc)*(x-Mc);
%     end
%     
% %     Pcx = Pxc(c)*Pc/sum(Pxc*Pc);
%     Pcx = Pxc(c);
    Sc(:,:) = S(c,:,:);
    Mc = M(c,:)';
    Pcx = -0.5*log(det(Sc))-0.5*((x-Mc)')*inv(Sc)*(x-Mc);
end
